// Emacs style mode select   -*- C++ -*- 
//-----------------------------------------------------------------------------
//
// $Id:$
//
// Copyright (C) 1993-1996 by id Software, Inc.
//
// This source is available for distribution and/or modification
// only under the terms of the DOOM Source Code License as
// published by id Software. All rights reserved.
//
// The source is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// FITNESS FOR A PARTICULAR PURPOSE. See the DOOM Source Code License
// for more details.
//
// $Log:$
//
// DESCRIPTION:
//
//-----------------------------------------------------------------------------

static const char
rcsid[] = "$Id: m_bbox.c,v 1.1 1997/02/03 22:45:10 b1 Exp $";


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <stdarg.h>
#include <sys/time.h>
#if defined(EMBEDDED)
#include "syscode.h"
#else
#include <unistd.h>
#endif

#include "doomdef.h"
#include "m_misc.h"
#include "i_video.h"
#include "i_sound.h"

#include "d_net.h"
#include "g_game.h"

#ifdef __GNUG__
#pragma implementation "i_system.h"
#endif
#include "i_system.h"




#ifdef EMBEDDED
extern int recalc_cache(unsigned cache_kb);
int	mb_used = 3;
#else
int	mb_used = 6;
#endif


void
I_Tactile
( int	on,
  int	off,
  int	total )
{
  // UNUSED.
  on = off = total = 0;
}

ticcmd_t	emptycmd;
ticcmd_t*	I_BaseTiccmd(void)
{
    return &emptycmd;
}


#ifdef EMBEDDED
#include "m_argv.h"
byte* I_ZoneBase(int *size) {
    int default_ram;
    int p = M_CheckParm("-mb");
    if (p && p + 1 < myargc) {
	char *end, *end2;
	default_ram = strtol(myargv[p+1], &end, 10) << 10;
	if (*end == '.') {
	    unsigned extra = strtoul(end + 1, &end2, 10), div = 1;
	    while (++end != end2) div *= 10;
	    default_ram += (1024 * extra + div / 2) / div;
	}
    } else default_ram = recalc_cache(mb_used << 10);
    return (byte*)malloc(*size = default_ram << 10);
}
#else
int  I_GetHeapSize (void)
{
    return mb_used*1024*1024;
}

byte* I_ZoneBase (int*	size)
{
    *size = mb_used*1024*1024;
    return (byte *) malloc (*size);
}
#endif



//
// I_GetTime
// returns time in 1/70th second tics
//
int  I_GetTime (void)
{
#ifdef EMBEDDED
    static unsigned last1 = 0, last2 = 0;
    unsigned t1 = sys_timer_ms();
    unsigned t2, t3, t4 = last2;

    t2 = t1 - last1;
    if (t2 >= 1000) {
	if (t2 < 2000) {
	    t2 -= 1000;
	    t4 += TICRATE;
	} else {
	    // slow path
	    t3 = t2 / 1000;
	    t2 -= t3 * 1000;
	    t4 += t3 * TICRATE;
	}
	last2 = t4;
	last1 = t1 - t2;
    }
#if TICRATE == 35
    return t4 + (t2 * 0x11eb9 >> 21);
#else
    return t4 + (t2 * TICRATE) / 1000;
#endif
#else
    struct timeval	tp;
    int			newtics;
    static int		basetime=0;
  
    gettimeofday(&tp, NULL);
    if (!basetime)
	basetime = tp.tv_sec;
    newtics = (tp.tv_sec-basetime)*TICRATE + tp.tv_usec*TICRATE/1000000;
    return newtics;
#endif
}



//
// I_Init
//
void I_Init (void)
{
    I_InitSound();
    //  I_InitGraphics();
}

//
// I_Quit
//
void I_Quit (void)
{
    D_QuitNetGame ();
    I_ShutdownSound();
    I_ShutdownMusic();
    M_SaveDefaults ();
    I_ShutdownGraphics();
    exit(0);
}

void I_WaitVBL(int count)
{
#if defined(EMBEDDED)
    sys_wait_ms(count*1000/70);
#else
    usleep (count * (1000000/70) );                                
#endif
}

void I_BeginRead(void)
{
}

void I_EndRead(void)
{
}

byte*	I_AllocLow(int length)
{
    byte*	mem;
        
    mem = (byte *)malloc (length);
    memset (mem,0,length);
    return mem;
}


//
// I_Error
//
extern boolean demorecording;

void I_Error (char *error, ...)
{
    va_list	argptr;

    // Message first.
    va_start (argptr,error);
    fprintf (stderr, "Error: ");
    vfprintf (stderr,error,argptr);
    fprintf (stderr, "\n");
    va_end (argptr);

    fflush( stderr );

    // Shutdown. Here might be other errors.
    if (demorecording)
	G_CheckDemoStatus();

    D_QuitNetGame ();
    I_ShutdownGraphics();
    
    exit(-1);
}
