// Emacs style mode select   -*- C++ -*- 
//-----------------------------------------------------------------------------
//
// $Id:$
//
// Copyright (C) 1993-1996 by id Software, Inc.
//
// This source is available for distribution and/or modification
// only under the terms of the DOOM Source Code License as
// published by id Software. All rights reserved.
//
// The source is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// FITNESS FOR A PARTICULAR PURPOSE. See the DOOM Source Code License
// for more details.
//
// $Log:$
//
// DESCRIPTION:
//	Archiving: SaveGame I/O.
//
//-----------------------------------------------------------------------------

static const char
rcsid[] = "$Id: p_tick.c,v 1.4 1997/02/03 16:47:55 b1 Exp $";

#include "i_system.h"
#include "z_zone.h"
#include "p_local.h"

// State.
#include "doomstat.h"
#include "r_state.h"

extern byte*	savebuffer;
byte*		save_p;

// does nothing if compiler uses packed structures
#define ALIGNP(t) s += ((byte*)p - s) & (sizeof(struct { char a; t b; }) - sizeof(t) - 1);

#define SAVEFMT(t, a) P_SaveFmt(t##_fmt, a);
#define LOADFMT(t, a) P_LoadFmt(t##_fmt, a);

#define player_t_fmt "v4112211*A4;v44v444*Bs444;4"
#define mobj_t_fmt "vvv444vv444vvv444444444v4S4444v44p422222v"
#define ceiling_t_fmt "vvv4r4444444"
#define vldoor_t_fmt "vvv4r44444"
#define floormove_t_fmt "vvv44r44244"
#define plat_t_fmt "vvvr4444444444"
#define lightflash_t_fmt "vvvr44444"
#define strobe_t_fmt "vvvr44444"
#define glow_t_fmt "vvvr444"

static const int savegamerep[] = {
    7+NUMPOWERS+NUMCARDS+1+MAXPLAYERS+2+NUMWEAPONS+NUMAMMO*2+7,
    NUMPSPRITES
};

static void P_SaveFmt(const char *f, void *p) {
    byte *s = (byte*)p, *d = save_p;
    int i, a, n = 0; const char *f1 = NULL;

    while((d - savebuffer) & 3) *d++ = 0;

    while (*f) switch(*f++) {
    case 'v':
	ALIGNP(void*)
	a = *(void**)s ? 1 : 0;
saveptr:
	*d++ = a;
	*d++ = a >> 8;
	*d++ = a >> 16;
	*d++ = a >> 24;
	s += sizeof(void*);
	break;
    case 'p':
	ALIGNP(void*)
	a = *(void**)s ? (*(player_t**)s - players) + 1 : 0;
	goto saveptr;
    case 'S':
	ALIGNP(void*)
	a = *(state_t**)s - states;
	goto saveptr;
    case 's':
	ALIGNP(void*)
	a = *(void**)s ? *(state_t**)s - states : 0;
	goto saveptr;
    case 'r':
	ALIGNP(void*)
	a = *(sector_t**)s - sectors;
	goto saveptr;
    case '1':
	*d++ = *(char*)s;
	s += sizeof(char);
	break;
    case '2':
	ALIGNP(short)
	a = *(short*)s; s += sizeof(short);
	*d++ = a;
	*d++ = a >> 8;
	break;
    case '4':
	ALIGNP(int)
	a = *(int*)s; s += sizeof(int);
	*d++ = a;
	*d++ = a >> 8;
	*d++ = a >> 16;
	*d++ = a >> 24;
	break;
    case '*':
	n = savegamerep[*f++ - 'A']; f1 = f;
	break;
    case ';':
	if (--n) f = f1;
	break;
    }
    save_p = d;
}

#define READ4 d[0]|d[1]<<8|d[2]<<16|d[3]<<24
static void P_LoadFmt(const char *f, void *p) {
    byte *s = (byte*)p, *d = save_p; void *b;
    int i, a, n = 0; const char *f1 = NULL;
    d += -(d - savebuffer) & 3;

    while (*f) switch(*f++) {
    case 'v':
	b = ((char*)0) + d[0];
loadptr:
	d += 4;
	ALIGNP(void*) *(void**)s = b; s += sizeof(void*);
	break;
    case 'p':
	a = READ4; b = a ? &players[a-1] : NULL;
	goto loadptr;
    case 'S':
	a = READ4; b = states + a;
	goto loadptr;
    case 's':
	a = READ4; b = a ? states + a : NULL;
	goto loadptr;
    case 'r':
	a = READ4; b = sectors + a;
	goto loadptr;
    case '1':
	*(char*)s = *d++; s += sizeof(char);
	break;
    case '2':
	a = d[0]|d[1]<<8; d += 2;
	ALIGNP(short) *(short*)s = a; s += sizeof(short);
	break;
    case '4':
	a = READ4; d += 4;
	ALIGNP(int) *(int*)s = a; s += sizeof(int);
	break;
    case '*':
	n = savegamerep[*f++ - 'A']; f1 = f;
	break;
    case ';':
	if (--n) f = f1;
	break;
    }
    save_p = d;
}
#undef READ4

//
// P_ArchivePlayers
//
void P_ArchivePlayers (void)
{
    int		i;
		
    for (i=0 ; i<MAXPLAYERS ; i++)
    {
	if (!playeringame[i]) continue;
	SAVEFMT(player_t, &players[i])
    }
}



//
// P_UnArchivePlayers
//
void P_UnArchivePlayers (void)
{
    int		i;
	
    for (i=0 ; i<MAXPLAYERS ; i++)
    {
	if (!playeringame[i]) continue;
	LOADFMT(player_t, &players[i])
	players[i].mo = NULL;	
	players[i].message = NULL;
	players[i].attacker = NULL;
    }
}


//
// P_ArchiveWorld
//
void P_ArchiveWorld (void)
{
    int			i;
    int			j;
    sector_t*		sec;
    line_t*		li;
    side_t*		si;
    short*		put;
	
    put = (short *)save_p;
    
    // do sectors
    for (i=0, sec = sectors ; i<numsectors ; i++,sec++)
    {
	*put++ = sec->floorheight >> FRACBITS;
	*put++ = sec->ceilingheight >> FRACBITS;
	*put++ = sec->floorpic;
	*put++ = sec->ceilingpic;
	*put++ = sec->lightlevel;
	*put++ = sec->special;		// needed?
	*put++ = sec->tag;		// needed?
    }

    
    // do lines
    for (i=0, li = lines ; i<numlines ; i++,li++)
    {
	*put++ = li->flags;
	*put++ = li->special;
	*put++ = li->tag;
	for (j=0 ; j<2 ; j++)
	{
	    if (li->sidenum[j] == -1)
		continue;
	    
	    si = &sides[li->sidenum[j]];

	    *put++ = si->textureoffset >> FRACBITS;
	    *put++ = si->rowoffset >> FRACBITS;
	    *put++ = si->toptexture;
	    *put++ = si->bottomtexture;
	    *put++ = si->midtexture;	
	}
    }
	
    save_p = (byte *)put;
}



//
// P_UnArchiveWorld
//
void P_UnArchiveWorld (void)
{
    int			i;
    int			j;
    sector_t*		sec;
    line_t*		li;
    side_t*		si;
    short*		get;
	
    get = (short *)save_p;
    
    // do sectors
    for (i=0, sec = sectors ; i<numsectors ; i++,sec++)
    {
	sec->floorheight = *get++ << FRACBITS;
	sec->ceilingheight = *get++ << FRACBITS;
	sec->floorpic = *get++;
	sec->ceilingpic = *get++;
	sec->lightlevel = *get++;
	sec->special = *get++;		// needed?
	sec->tag = *get++;		// needed?
	sec->specialdata = 0;
	sec->soundtarget = 0;
    }
    
    // do lines
    for (i=0, li = lines ; i<numlines ; i++,li++)
    {
	li->flags = *get++;
	li->special = *get++;
	li->tag = *get++;
	for (j=0 ; j<2 ; j++)
	{
	    if (li->sidenum[j] == -1)
		continue;
	    si = &sides[li->sidenum[j]];
	    si->textureoffset = *get++ << FRACBITS;
	    si->rowoffset = *get++ << FRACBITS;
	    si->toptexture = *get++;
	    si->bottomtexture = *get++;
	    si->midtexture = *get++;
	}
    }
    save_p = (byte *)get;	
}





//
// Thinkers
//
typedef enum
{
    tc_end,
    tc_mobj

} thinkerclass_t;



//
// P_ArchiveThinkers
//
void P_ArchiveThinkers (void)
{
    thinker_t*		th;
	
    // save off the current thinkers
    for (th = thinkercap.next ; th != &thinkercap ; th=th->next)
    {
	if (th->function.acp1 == (actionf_p1)P_MobjThinker)
	{
	    *save_p++ = tc_mobj;
	    SAVEFMT(mobj_t, th)
	    continue;
	}
		
	// I_Error ("P_ArchiveThinkers: Unknown thinker function");
    }

    // add a terminating marker
    *save_p++ = tc_end;	
}



//
// P_UnArchiveThinkers
//
void P_UnArchiveThinkers (void)
{
    byte		tclass;
    thinker_t*		currentthinker;
    thinker_t*		next;
    mobj_t*		mobj;
    
    // remove all the current thinkers
    currentthinker = thinkercap.next;
    while (currentthinker != &thinkercap)
    {
	next = currentthinker->next;
	
	if (currentthinker->function.acp1 == (actionf_p1)P_MobjThinker)
	    P_RemoveMobj ((mobj_t *)currentthinker);
	else
	    Z_Free (currentthinker);

	currentthinker = next;
    }
    P_InitThinkers ();
	
    // read in saved thinkers
    while (1)
    {
	tclass = *save_p++;
	switch (tclass)
	{
	  case tc_end:
	    return; 	// end of list
			
	  case tc_mobj:
	    mobj = Z_Malloc (sizeof(*mobj), PU_LEVEL, NULL);
	    LOADFMT(mobj_t, mobj)
	    mobj->target = NULL;
	    if (mobj->player)
	    {
		mobj->player->mo = mobj;
	    }
	    P_SetThingPosition (mobj);
	    mobj->info = &mobjinfo[mobj->type];
	    mobj->floorz = mobj->subsector->sector->floorheight;
	    mobj->ceilingz = mobj->subsector->sector->ceilingheight;
	    mobj->thinker.function.acp1 = (actionf_p1)P_MobjThinker;
	    P_AddThinker (&mobj->thinker);
	    break;
			
	  default:
	    I_Error ("Unknown tclass %i in savegame",tclass);
	}
	
    }

}


//
// P_ArchiveSpecials
//
enum
{
    tc_ceiling,
    tc_door,
    tc_floor,
    tc_plat,
    tc_flash,
    tc_strobe,
    tc_glow,
    tc_endspecials

} specials_e;	



//
// Things to handle:
//
// T_MoveCeiling, (ceiling_t: sector_t * swizzle), - active list
// T_VerticalDoor, (vldoor_t: sector_t * swizzle),
// T_MoveFloor, (floormove_t: sector_t * swizzle),
// T_LightFlash, (lightflash_t: sector_t * swizzle),
// T_StrobeFlash, (strobe_t: sector_t *),
// T_Glow, (glow_t: sector_t *),
// T_PlatRaise, (plat_t: sector_t *), - active list
//
void P_ArchiveSpecials (void)
{
    thinker_t*		th;
    int			i;
	
    // save off the current thinkers
    for (th = thinkercap.next ; th != &thinkercap ; th=th->next)
    {
	if (th->function.acv == (actionf_v)NULL)
	{
	    for (i = 0; i < MAXCEILINGS;i++)
		if (activeceilings[i] == (ceiling_t *)th)
		    break;
	    
	    if (i<MAXCEILINGS)
	    {
		*save_p++ = tc_ceiling;
		SAVEFMT(ceiling_t, th)
	    }
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_MoveCeiling)
	{
	    *save_p++ = tc_ceiling;
	    SAVEFMT(ceiling_t, th)
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_VerticalDoor)
	{
	    *save_p++ = tc_door;
	    SAVEFMT(vldoor_t, th);
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_MoveFloor)
	{
	    *save_p++ = tc_floor;
	    SAVEFMT(floormove_t, th)
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_PlatRaise)
	{
	    *save_p++ = tc_plat;
	    SAVEFMT(plat_t, th)
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_LightFlash)
	{
	    *save_p++ = tc_flash;
	    SAVEFMT(lightflash_t, th)
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_StrobeFlash)
	{
	    *save_p++ = tc_strobe;
	    SAVEFMT(strobe_t, th)
	    continue;
	}
			
	if (th->function.acp1 == (actionf_p1)T_Glow)
	{
	    *save_p++ = tc_glow;
	    SAVEFMT(glow_t, th)
	    continue;
	}
    }
	
    // add a terminating marker
    *save_p++ = tc_endspecials;	
}


//
// P_UnArchiveSpecials
//
void P_UnArchiveSpecials (void)
{
    byte		tclass;
    ceiling_t*		ceiling;
    vldoor_t*		door;
    floormove_t*	floor;
    plat_t*		plat;
    lightflash_t*	flash;
    strobe_t*		strobe;
    glow_t*		glow;
	
	
    // read in saved thinkers
    while (1)
    {
	tclass = *save_p++;
	switch (tclass)
	{
	  case tc_endspecials:
	    return;	// end of list
			
	  case tc_ceiling:
	    ceiling = Z_Malloc (sizeof(*ceiling), PU_LEVEL, NULL);
	    LOADFMT(ceiling_t, ceiling)
	    ceiling->sector->specialdata = ceiling;

	    if (ceiling->thinker.function.acp1)
		ceiling->thinker.function.acp1 = (actionf_p1)T_MoveCeiling;

	    P_AddThinker (&ceiling->thinker);
	    P_AddActiveCeiling(ceiling);
	    break;
				
	  case tc_door:
	    door = Z_Malloc (sizeof(*door), PU_LEVEL, NULL);
	    LOADFMT(vldoor_t, door)
	    door->sector->specialdata = door;
	    door->thinker.function.acp1 = (actionf_p1)T_VerticalDoor;
	    P_AddThinker (&door->thinker);
	    break;
				
	  case tc_floor:
	    floor = Z_Malloc (sizeof(*floor), PU_LEVEL, NULL);
	    LOADFMT(floormove_t, floor)
	    floor->sector->specialdata = floor;
	    floor->thinker.function.acp1 = (actionf_p1)T_MoveFloor;
	    P_AddThinker (&floor->thinker);
	    break;
				
	  case tc_plat:
	    plat = Z_Malloc (sizeof(*plat), PU_LEVEL, NULL);
	    LOADFMT(plat_t, plat)
	    plat->sector->specialdata = plat;

	    if (plat->thinker.function.acp1)
		plat->thinker.function.acp1 = (actionf_p1)T_PlatRaise;

	    P_AddThinker (&plat->thinker);
	    P_AddActivePlat(plat);
	    break;
				
	  case tc_flash:
	    flash = Z_Malloc (sizeof(*flash), PU_LEVEL, NULL);
	    LOADFMT(lightflash_t, flash)
	    flash->thinker.function.acp1 = (actionf_p1)T_LightFlash;
	    P_AddThinker (&flash->thinker);
	    break;
				
	  case tc_strobe:
	    strobe = Z_Malloc (sizeof(*strobe), PU_LEVEL, NULL);
	    LOADFMT(strobe_t, strobe)
	    strobe->thinker.function.acp1 = (actionf_p1)T_StrobeFlash;
	    P_AddThinker (&strobe->thinker);
	    break;
				
	  case tc_glow:
	    glow = Z_Malloc (sizeof(*glow), PU_LEVEL, NULL);
	    LOADFMT(glow_t, glow)
	    glow->thinker.function.acp1 = (actionf_p1)T_Glow;
	    P_AddThinker (&glow->thinker);
	    break;
				
	  default:
	    I_Error ("P_UnarchiveSpecials:Unknown tclass %i "
		     "in savegame",tclass);
	}
	
    }

}

