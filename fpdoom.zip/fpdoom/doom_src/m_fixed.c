// Emacs style mode select   -*- C++ -*- 
//-----------------------------------------------------------------------------
//
// $Id:$
//
// Copyright (C) 1993-1996 by id Software, Inc.
//
// This source is available for distribution and/or modification
// only under the terms of the DOOM Source Code License as
// published by id Software. All rights reserved.
//
// The source is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// FITNESS FOR A PARTICULAR PURPOSE. See the DOOM Source Code License
// for more details.
//
// $Log:$
//
// DESCRIPTION:
//	Fixed point implementation.
//
//-----------------------------------------------------------------------------


static const char
rcsid[] = "$Id: m_bbox.c,v 1.1 1997/02/03 22:45:10 b1 Exp $";

#include "stdlib.h"

#include "doomtype.h"
#include "i_system.h"

#ifdef __GNUG__
#pragma implementation "m_fixed.h"
#endif
#include "m_fixed.h"

#ifdef EMBEDDED
#ifndef USE_ASM
fixed_t FixedMul(fixed_t a, fixed_t b) {
    return ((long long)a * (long long)b) >> FRACBITS;
}

fixed_t FixedDiv(fixed_t a, fixed_t b) {
	unsigned r0 = a, r1 = b;
	unsigned r12 = r0 ^ r1, r2, r3;
	r2 = r0 ^ ((int)r0 >> 31);
	r3 = r1 ^ ((int)r1 >> 31);
	r2 -= ((int)r0 >> 31);
	r3 -= ((int)r1 >> 31);
	r1 = r2 >> 15; r2 <<= 17;
	r0 = 0x7fffffff ^ ((int)r12 >> 31);
	if (r1 >= r3) return r0;
	r0 = 2;
	for (;;) {
		int end = r0;
		r1 = r1 << 1 | r2 >> 31;
		r2 <<= 1;
		r0 += r0;
		if (r1 >= r3) r0++, r1 -= r3;
		if (end < 0) break;
	}
	if (r12 >> 31) r0 = -r0;
	return r0;
}
#endif
#else


// Fixme. __USE_C_FIXED__ or something.

fixed_t
FixedMul
( fixed_t	a,
  fixed_t	b )
{
    return ((long long) a * (long long) b) >> FRACBITS;
}



//
// FixedDiv, C version.
//

fixed_t
FixedDiv
( fixed_t	a,
  fixed_t	b )
{
    if ( (abs(a)>>14) >= abs(b))
	return (a^b)<0 ? MININT : MAXINT;
    return FixedDiv2 (a,b);
}



fixed_t
FixedDiv2
( fixed_t	a,
  fixed_t	b )
{
#if 1
    long long c;
    c = ((long long)a<<16) / ((long long)b);
    return (fixed_t) c;
#else

    double c;

    c = ((double)a) / ((double)b) * FRACUNIT;

    if (c >= 2147483648.0 || c < -2147483648.0)
	I_Error("FixedDiv: divide by zero");
    return (fixed_t) c;
#endif
}
#endif
