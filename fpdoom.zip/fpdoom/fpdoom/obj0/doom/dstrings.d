obj0/doom/dstrings.o: ../doom_src/dstrings.c ../doom_src/dstrings.h \
 ../doom_src/d_englsh.h
../doom_src/dstrings.h:
../doom_src/d_englsh.h:
