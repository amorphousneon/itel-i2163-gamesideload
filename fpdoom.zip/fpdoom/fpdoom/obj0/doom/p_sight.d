obj0/doom/p_sight.o: ../doom_src/p_sight.c ../doom_src/doomdef.h \
 ../doom_src/i_system.h ../doom_src/d_ticcmd.h ../doom_src/doomtype.h \
 ../doom_src/d_event.h ../doom_src/p_local.h ../doom_src/r_local.h \
 ../doom_src/tables.h ../doom_src/m_fixed.h ../doom_src/r_data.h \
 ../doom_src/r_defs.h ../doom_src/d_think.h ../doom_src/p_mobj.h \
 ../doom_src/doomdata.h ../doom_src/info.h ../doom_src/r_state.h \
 ../doom_src/d_player.h ../doom_src/d_items.h ../doom_src/p_pspr.h \
 ../doom_src/r_main.h ../doom_src/r_bsp.h ../doom_src/r_segs.h \
 ../doom_src/r_plane.h ../doom_src/r_things.h ../doom_src/r_draw.h \
 ../doom_src/p_spec.h
../doom_src/doomdef.h:
../doom_src/i_system.h:
../doom_src/d_ticcmd.h:
../doom_src/doomtype.h:
../doom_src/d_event.h:
../doom_src/p_local.h:
../doom_src/r_local.h:
../doom_src/tables.h:
../doom_src/m_fixed.h:
../doom_src/r_data.h:
../doom_src/r_defs.h:
../doom_src/d_think.h:
../doom_src/p_mobj.h:
../doom_src/doomdata.h:
../doom_src/info.h:
../doom_src/r_state.h:
../doom_src/d_player.h:
../doom_src/d_items.h:
../doom_src/p_pspr.h:
../doom_src/r_main.h:
../doom_src/r_bsp.h:
../doom_src/r_segs.h:
../doom_src/r_plane.h:
../doom_src/r_things.h:
../doom_src/r_draw.h:
../doom_src/p_spec.h:
