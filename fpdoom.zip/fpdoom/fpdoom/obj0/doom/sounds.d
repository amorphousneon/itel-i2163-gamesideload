obj0/doom/sounds.o: ../doom_src/sounds.c ../doom_src/doomtype.h \
 ../doom_src/sounds.h
../doom_src/doomtype.h:
../doom_src/sounds.h:
