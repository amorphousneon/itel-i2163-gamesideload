obj0/doom/i_sound.o: ../doom_src/i_sound.c ../doom_src/z_zone.h \
 ../doom_src/i_system.h ../doom_src/d_ticcmd.h ../doom_src/doomtype.h \
 ../doom_src/d_event.h ../doom_src/i_sound.h ../doom_src/doomdef.h \
 ../doom_src/doomstat.h ../doom_src/doomdata.h ../doom_src/d_net.h \
 ../doom_src/d_player.h ../doom_src/d_items.h ../doom_src/p_pspr.h \
 ../doom_src/m_fixed.h ../doom_src/tables.h ../doom_src/info.h \
 ../doom_src/d_think.h ../doom_src/p_mobj.h ../doom_src/sounds.h \
 ../doom_src/m_argv.h ../doom_src/m_misc.h ../doom_src/w_wad.h
../doom_src/z_zone.h:
../doom_src/i_system.h:
../doom_src/d_ticcmd.h:
../doom_src/doomtype.h:
../doom_src/d_event.h:
../doom_src/i_sound.h:
../doom_src/doomdef.h:
../doom_src/doomstat.h:
../doom_src/doomdata.h:
../doom_src/d_net.h:
../doom_src/d_player.h:
../doom_src/d_items.h:
../doom_src/p_pspr.h:
../doom_src/m_fixed.h:
../doom_src/tables.h:
../doom_src/info.h:
../doom_src/d_think.h:
../doom_src/p_mobj.h:
../doom_src/sounds.h:
../doom_src/m_argv.h:
../doom_src/m_misc.h:
../doom_src/w_wad.h:
