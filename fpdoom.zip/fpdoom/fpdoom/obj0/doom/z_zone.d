obj0/doom/z_zone.o: ../doom_src/z_zone.c ../doom_src/z_zone.h \
 ../doom_src/i_system.h ../doom_src/d_ticcmd.h ../doom_src/doomtype.h \
 ../doom_src/d_event.h ../doom_src/doomdef.h
../doom_src/z_zone.h:
../doom_src/i_system.h:
../doom_src/d_ticcmd.h:
../doom_src/doomtype.h:
../doom_src/d_event.h:
../doom_src/doomdef.h:
