obj0/doom/doomstat.o: ../doom_src/doomstat.c ../doom_src/doomstat.h \
 ../doom_src/doomdata.h ../doom_src/doomtype.h ../doom_src/doomdef.h \
 ../doom_src/d_net.h ../doom_src/d_player.h ../doom_src/d_items.h \
 ../doom_src/p_pspr.h ../doom_src/m_fixed.h ../doom_src/tables.h \
 ../doom_src/info.h ../doom_src/d_think.h ../doom_src/p_mobj.h \
 ../doom_src/d_ticcmd.h
../doom_src/doomstat.h:
../doom_src/doomdata.h:
../doom_src/doomtype.h:
../doom_src/doomdef.h:
../doom_src/d_net.h:
../doom_src/d_player.h:
../doom_src/d_items.h:
../doom_src/p_pspr.h:
../doom_src/m_fixed.h:
../doom_src/tables.h:
../doom_src/info.h:
../doom_src/d_think.h:
../doom_src/p_mobj.h:
../doom_src/d_ticcmd.h:
